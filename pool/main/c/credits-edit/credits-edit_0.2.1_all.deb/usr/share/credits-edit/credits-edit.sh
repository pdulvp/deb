#!/usr/bin/env bash
# credits-edit.sh - Per-folder credits playlists (.xspf) for video folders
#
# Keeps a credits.config.json in the current folder (starting credits video
# with optional start/end seconds, movie start/end seconds, ending credits
# video with optional start/end seconds) and generates one VLC .xspf beside
# every video found recursively in the current folder, playing starting
# credits -> movie -> ending credits, each with its optional times. Existing
# .xspf files are overwritten, so a changed configuration is picked up on the
# next generate. A negative end value is resolved with ffprobe as "duration
# minus N seconds".
#
# Usage:
#   credits-edit                  Interactive menu for the current folder
#   credits-edit menu             Same as above
#   credits-edit show             Print the current folder's configuration
#   credits-edit config [section] Edit the configuration; section is all,
#                                 starting_credits, movie or ending_credits
#   credits-edit generate         Generate the .xspf files
#   credits-edit usage            Show the help

set -uo pipefail

CONFIG_NAME="credits.config.json"

VIDEO_EXTS=(mkv mp4 avi mov webm m4v mpg mpeg ts m2ts wmv flv ogv 3gp)

die() {
	echo "Error: $*" >&2
	exit 1
}

need_jq() {
	command -v jq >/dev/null 2>&1 || die "jq is required (apt install jq)"
}

is_number() {
	[[ "${1-}" =~ ^-?[0-9]+([.][0-9]+)?$ ]]
}

config_path() {
	printf '%s/%s' "$PWD" "$CONFIG_NAME"
}

# Videos of the current folder, recursively, NUL-separated.
find_videos() {
	local -a expr=()
	local e
	for e in "${VIDEO_EXTS[@]}"; do
		expr+=(-iname "*.$e" -o)
	done
	unset "expr[${#expr[@]}-1]"
	find . -type f \( "${expr[@]}" \) -print0
}

# --- configuration ---------------------------------------------------------

load_config_vars() {
	local f v
	f="$(config_path)"
	if [ -f "$f" ]; then
		S_FILE=$(jq -r '.starting_credits.file // empty' "$f")
		S_START=$(jq -r '.starting_credits.start // empty' "$f")
		S_END=$(jq -r '.starting_credits.end // empty' "$f")
		M_START=$(jq -r '.movie.start // empty' "$f")
		M_END=$(jq -r '.movie.end // empty' "$f")
		E_FILE=$(jq -r '.ending_credits.file // empty' "$f")
		E_START=$(jq -r '.ending_credits.start // empty' "$f")
		E_END=$(jq -r '.ending_credits.end // empty' "$f")
		for v in "$S_START" "$S_END" "$M_START" "$M_END" "$E_START" "$E_END"; do
			if [ -n "$v" ] && ! is_number "$v"; then
				die "$f holds a non-numeric time value: '$v'"
			fi
		done
	else
		S_FILE=""; S_START=""; S_END=""
		M_START=""; M_END=""
		E_FILE=""; E_START=""; E_END=""
	fi
}

jstr() {
	if [ -z "$1" ]; then printf 'null'; else jq -cn --arg v "$1" '$v'; fi
}

# Times are validated before they reach here, so an empty value is the only
# case that needs mapping; anything else is already a JSON number.
jnum() {
	if [ -z "$1" ]; then printf 'null'; else printf '%s' "$1"; fi
}

save_config() {
	local f
	f="$(config_path)"
	jq -n \
		--argjson sf "$(jstr "$S_FILE")" \
		--argjson ss "$(jnum "$S_START")" \
		--argjson se "$(jnum "$S_END")" \
		--argjson ms "$(jnum "$M_START")" \
		--argjson me "$(jnum "$M_END")" \
		--argjson ef "$(jstr "$E_FILE")" \
		--argjson es "$(jnum "$E_START")" \
		--argjson ee "$(jnum "$E_END")" \
		'{version: 1,
		  starting_credits: {file: $sf, start: $ss, end: $se},
		  movie:            {start: $ms, end: $me},
		  ending_credits:   {file: $ef, start: $es, end: $ee}}' > "$f.tmp.$$" \
		&& mv "$f.tmp.$$" "$f"
}

# --- interactive prompts ---------------------------------------------------

# Every prompt writes its answer to PROMPT_RESULT, never to stdout, so the
# caller can assign it; informational output goes to stderr.

prompt_number() {
	# $1 label, $2 current value, $3 allow_negative (yes|no)
	local label="$1" current="$2" allow_neg="$3" ans=""
	while true; do
		if [ -n "$current" ]; then
			read -r -p "$label [$current]: " ans || ans=""
		else
			read -r -p "$label (seconds; empty = unset, none = clear): " ans || ans=""
		fi
		ans="${ans:-$current}"
		if [ -z "$ans" ] || [ "$ans" = "none" ]; then
			PROMPT_RESULT=""
			return 0
		fi
		if is_number "$ans"; then
			if [ "$allow_neg" != "yes" ] && [[ "$ans" =~ ^- ]]; then
				echo "  a start time cannot be negative" >&2
				continue
			fi
			PROMPT_RESULT="$ans"
			return 0
		fi
		echo "  not a number: '$ans'" >&2
	done
}

prompt_file() {
	# $1 label, $2 current value. Accepts a number from the list of this
	# folder's videos, or a path.
	local label="$1" current="$2" ans="" i f
	local -a cands=()
	while IFS= read -r -d '' f; do
		cands+=("$f")
	done < <(find_videos)
	if [ "${#cands[@]}" -gt 0 ]; then
		echo "Videos found in this folder:" >&2
		i=0
		for f in "${cands[@]}"; do
			i=$((i + 1))
			echo "  $i) ${f#./}" >&2
		done
	fi
	if [ -n "$current" ]; then
		read -r -p "$label [$current] (number, path; empty = keep, none = clear): " ans || ans=""
	else
		read -r -p "$label (number, path; empty = unset): " ans || ans=""
	fi
	ans="${ans:-$current}"
	case "$ans" in
		""|none)
			PROMPT_RESULT=""
			return 0
			;;
	esac
	if [[ "$ans" =~ ^[0-9]+$ ]] && [ "$ans" -ge 1 ] && [ "$ans" -le "${#cands[@]}" ]; then
		PROMPT_RESULT="${cands[$((ans - 1))]#./}"
		return 0
	fi
	PROMPT_RESULT="$ans"
}

# --- commands --------------------------------------------------------------

cmd_show() {
	local f
	f="$(config_path)"
	if [ -f "$f" ]; then
		jq . "$f"
	else
		echo "No $CONFIG_NAME in $PWD yet."
	fi
}

cmd_config_edit() {
	local section="${1:-all}" f
	need_jq
	load_config_vars
	case "$section" in
		all)
			prompt_file "Starting credits file" "$S_FILE"; S_FILE="$PROMPT_RESULT"
			prompt_number "Starting credits start" "$S_START" no; S_START="$PROMPT_RESULT"
			prompt_number "Starting credits end (negative = duration - N)" "$S_END" yes; S_END="$PROMPT_RESULT"
			prompt_number "Movie start" "$M_START" no; M_START="$PROMPT_RESULT"
			prompt_number "Movie end (negative = duration - N)" "$M_END" yes; M_END="$PROMPT_RESULT"
			prompt_file "Ending credits file" "$E_FILE"; E_FILE="$PROMPT_RESULT"
			prompt_number "Ending credits start" "$E_START" no; E_START="$PROMPT_RESULT"
			prompt_number "Ending credits end (negative = duration - N)" "$E_END" yes; E_END="$PROMPT_RESULT"
			;;
		starting_credits)
			prompt_file "Starting credits file" "$S_FILE"; S_FILE="$PROMPT_RESULT"
			prompt_number "Starting credits start" "$S_START" no; S_START="$PROMPT_RESULT"
			prompt_number "Starting credits end (negative = duration - N)" "$S_END" yes; S_END="$PROMPT_RESULT"
			;;
		movie)
			prompt_number "Movie start" "$M_START" no; M_START="$PROMPT_RESULT"
			prompt_number "Movie end (negative = duration - N)" "$M_END" yes; M_END="$PROMPT_RESULT"
			;;
		ending_credits)
			prompt_file "Ending credits file" "$E_FILE"; E_FILE="$PROMPT_RESULT"
			prompt_number "Ending credits start" "$E_START" no; E_START="$PROMPT_RESULT"
			prompt_number "Ending credits end (negative = duration - N)" "$E_END" yes; E_END="$PROMPT_RESULT"
			;;
		*)
			die "unknown section '$section' (all | starting_credits | movie | ending_credits)"
			;;
	esac
	for f in "$S_FILE" "$E_FILE"; do
		if [ -n "$f" ] && [ ! -e "$f" ]; then
			echo "Warning: '$f' does not exist from $PWD; saved anyway" >&2
		fi
	done
	save_config
	echo "Saved $(config_path)"
}

# --- xspf generation -------------------------------------------------------

# Percent-encode a path per segment so it is a valid file:// URI.
uri_encode() {
	jq -rn --arg p "$1" '$p | split("/") | map(@uri) | join("/")'
}

# Resolve an end value: a negative value means "ffprobe duration plus this
# value", i.e. duration minus N seconds. Prints the resolved end, or empty.
resolve_end() {
	local file="$1" end="$2" dur
	if [ -z "$end" ]; then
		return 0
	fi
	if [[ "$end" =~ ^- ]]; then
		if ! command -v ffprobe >/dev/null 2>&1; then
			echo "Warning: ffprobe not found; dropping stop-time for $file" >&2
			return 0
		fi
		dur=$(ffprobe -v error -show_entries format=duration \
			-of default=noprint_wrappers=1:nokey=1 "$file" 2>/dev/null) || dur=""
		if ! is_number "$dur"; then
			echo "Warning: could not read the duration of $file; dropping stop-time" >&2
			return 0
		fi
		awk -v d="$dur" -v e="$end" 'BEGIN { r = d + e; if (r < 0) r = 0; printf "%.3f", r }'
	else
		printf '%s' "$end"
	fi
}

emit_track() {
	# $1 absolute file, $2 start, $3 end, $4 track id
	local file="$1" start="$2" end="$3" id="$4"
	local rend
	rend=$(resolve_end "$file" "$end")
	printf '\t\t<track>\n'
	printf '\t\t\t<location>file://%s</location>\n' "$(uri_encode "$file")"
	printf '\t\t\t<extension application="http://www.videolan.org/vlc/playlist/0">\n'
	printf '\t\t\t\t<vlc:id>%s</vlc:id>\n' "$id"
	if [ -n "$start" ]; then
		printf '\t\t\t\t<vlc:option>start-time=%s</vlc:option>\n' "$start"
	fi
	if [ -n "$rend" ]; then
		printf '\t\t\t\t<vlc:option>stop-time=%s</vlc:option>\n' "$rend"
	fi
	printf '\t\t\t</extension>\n'
	printf '\t\t</track>\n'
}

cmd_generate() {
	local f
	f="$(config_path)"
	[ -f "$f" ] || die "no $CONFIG_NAME in $PWD; run 'credits-edit config' first"
	need_jq
	load_config_vars

	# Credits files picked from this folder are videos too; they must not
	# get a playlist of their own.
	local -A exclude=()
	local c abs
	for c in "$S_FILE" "$E_FILE"; do
		[ -n "$c" ] || continue
		abs=$(realpath -m -- "$c")
		if [ ! -e "$abs" ]; then
			echo "Warning: credits file not found: $c" >&2
		fi
		exclude["$abs"]=1
	done

	local vid absvid base xspf tmp id i existed
	local created=0 overwritten=0 excluded=0
	while IFS= read -r -d '' vid; do
		absvid=$(realpath -m -- "$vid")
		if [ -n "${exclude[$absvid]:-}" ]; then
			excluded=$((excluded + 1))
			continue
		fi
		base="${vid%.*}"
		xspf="$base.xspf"
		if [ -e "$xspf" ]; then
			existed=1
		else
			existed=0
		fi
		tmp="$xspf.tmp.$$"
		{
			printf '<?xml version="1.0" encoding="UTF-8"?>\n'
			printf '<playlist xmlns="http://xspf.org/ns/0/" xmlns:vlc="http://www.videolan.org/vlc/playlist/ns/0/" version="1">\n'
			printf '\t<title>Playlist</title>\n'
			printf '\t<trackList>\n'
			id=0
			if [ -n "$S_FILE" ]; then
				emit_track "$(realpath -m -- "$S_FILE")" "$S_START" "$S_END" "$id"
				id=$((id + 1))
			fi
			emit_track "$absvid" "$M_START" "$M_END" "$id"
			id=$((id + 1))
			if [ -n "$E_FILE" ]; then
				emit_track "$(realpath -m -- "$E_FILE")" "$E_START" "$E_END" "$id"
				id=$((id + 1))
			fi
			printf '\t</trackList>\n'
			printf '\t<extension application="http://www.videolan.org/vlc/playlist/0">\n'
			for ((i = 0; i < id; i++)); do
				printf '\t\t<vlc:item tid="%s"/>\n' "$i"
			done
			printf '\t</extension>\n'
			printf '</playlist>\n'
		} > "$tmp"
		mv "$tmp" "$xspf"
		if [ "$existed" = 1 ]; then
			overwritten=$((overwritten + 1))
			echo "overwritten: ${xspf#./}"
		else
			created=$((created + 1))
			echo "created: ${xspf#./}"
		fi
	done < <(find_videos)

	echo "Done: $created created, $overwritten overwritten, $excluded credits file(s) excluded."
}

# --- menu ------------------------------------------------------------------

cmd_menu() {
	local choice=""
	while true; do
		echo ""
		echo "credits-edit - current folder: $PWD"
		if [ -f "$(config_path)" ]; then
			echo "config: $CONFIG_NAME present"
		else
			echo "config: no $CONFIG_NAME here yet (created on first edit)"
		fi
		cat <<'EOF'
  1) Show configuration
  2) Edit the whole configuration
  3) Edit starting credits (file, start, end)
  4) Edit movie (start, end)
  5) Edit ending credits (file, start, end)
  6) Generate .xspf files for every video in this folder
  0) Quit
EOF
		read -r -p "Choice: " choice || break
		case "$choice" in
			1) cmd_show ;;
			2) cmd_config_edit all ;;
			3) cmd_config_edit starting_credits ;;
			4) cmd_config_edit movie ;;
			5) cmd_config_edit ending_credits ;;
			6)
				if [ ! -f "$(config_path)" ]; then
					echo "No $CONFIG_NAME here yet; use 2-5 to create one first." >&2
				else
					cmd_generate
				fi
				;;
			0) break ;;
			*) echo "Unknown choice: '$choice'" >&2 ;;
		esac
	done
}

usage() {
	cat <<EOF
credits-edit - per-folder credits playlists (.xspf) for video folders

Usage:
  credits-edit                  Interactive menu for the current folder
  credits-edit menu             Same
  credits-edit show             Print the current folder's $CONFIG_NAME
  credits-edit config [section] Edit the configuration; section is all
                                (default), starting_credits, movie or
                                ending_credits
  credits-edit generate         Create one .xspf beside each video found
                                recursively in the current folder, playing
                                starting credits -> movie -> ending credits;
                                existing .xspf files are overwritten
  credits-edit usage            Show this help

Configuration ($CONFIG_NAME, one per folder):
  starting_credits / ending_credits: file (path, relative to this folder or
    absolute), start and end in seconds (both optional)
  movie: start and end in seconds (both optional)
  A negative end value is resolved with ffprobe at generate time as
  "duration minus N seconds".
EOF
}

main() {
	case "${1-}" in
		""|menu) cmd_menu ;;
		show) cmd_show ;;
		config) shift; cmd_config_edit "${1:-all}" ;;
		generate) cmd_generate ;;
		usage|--help|-h) usage ;;
		*) die "unknown command '${1-}' (try 'credits-edit usage')" ;;
	esac
}

main "$@"
