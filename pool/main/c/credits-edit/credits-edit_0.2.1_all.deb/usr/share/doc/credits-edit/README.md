# credits-edit

Per-folder credits playlists for video folders. `credits-edit` is a single
bash script, callable from any folder, that keeps a `credits.config.json`
in the folder you run it from and generates one VLC `.xspf` playlist beside
every video found recursively in that folder.

Each generated playlist plays, in order:

1. the starting credits video (with its optional start/end seconds),
2. the movie itself (with its optional start/end seconds),
3. the ending credits video (with its optional start/end seconds).

Existing `.xspf` files are overwritten on each generate, so a changed
configuration is picked up. A negative `end` value is resolved at generate
time with ffprobe as "duration minus N seconds".

## Install

Build the package from a clone and install it with apt (which resolves the
dependencies):

```sh
packaging/build-deb.sh
sudo apt install ./build/credits-edit_<version>_all.deb
```

The package puts the script at `/usr/share/credits-edit/credits-edit.sh`
and symlinks `/usr/bin/credits-edit` to it. `Depends: bash, coreutils,
findutils, jq`; `Recommends: ffmpeg` (ffprobe, only for negative end times).

## Usage

```sh
credits-edit                  # interactive menu for the current folder
credits-edit config           # edit the whole credits.config.json
credits-edit config movie     # edit only the movie start/end seconds
credits-edit generate         # create the .xspf files
credits-edit show             # print the current folder's configuration
credits-edit usage            # full help
```

Run with no arguments, the menu lets you show the configuration, edit it
whole or one section at a time (starting credits, movie, ending credits),
and run the generation.

## Configuration

`credits.config.json`, one per folder, created on the first edit:

```json
{
  "version": 1,
  "starting_credits": { "file": "Intro Credits.mp4", "start": null, "end": -5 },
  "movie": { "start": 90, "end": -30 },
  "ending_credits": { "file": "Outro Credits.mp4", "start": null, "end": 8 }
}
```

- `file`: path relative to the folder holding the config, or absolute.
  `null` means no credits video for that slot.
- `start` / `end`: seconds, `null` means unset. Times apply to every
  generated playlist: the credits times to their own track, the movie
  times to the movie track.
- A negative `end` (e.g. `-30`) means "play until 30 seconds before the
  end", computed with ffprobe on that file at generate time.

## Generation

`credits-edit generate` walks the current folder recursively, and for every
video file (mkv mp4 avi mov webm m4v mpg mpeg ts m2ts wmv flv ogv 3gp) writes
`<video>.xspf` right beside it, overwriting any existing one. The credits
files themselves are excluded when they live in this folder.

The `.xspf` is a VLC playlist: absolute `file:///` locations
(percent-encoded), and `start-time=` / `stop-time=` VLC options on the tracks
that have times set.

## Build

`packaging/build-deb.sh [x.y.z]` stages a whitelist of the repository into
`build/credits-edit_<version>_all/`, writes `DEBIAN/control` and runs
`dpkg-deb --build --root-owner-group`. The version comes from the argument
or the `VERSION` file; `build/` is gitignored.
