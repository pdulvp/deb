# prel

A git management toolkit for configuring commit attribution and hooks across repositories.

## Quick Start

Run from any directory in a git repository:

```bash
prel                    # the command list
prel init register      # set this repository up
prel init status        # what a commit here would file
```

## Installing

A release carries a `.deb`, which is the shortest way onto a Debian or Ubuntu
machine. `apt` rather than `dpkg -i`, so the dependencies are resolved:

```bash
sudo apt install ./prel_0.1.0_all.deb
```

The package puts the tree under `/usr/share/prel` and symlinks `/usr/bin/prel`
to it, so `prel` works from anywhere and the hooks, the skill and the memories
are shared from there. It is `Architecture: all` - prel is shell, so there is
nothing to compile and one file fits every machine.

From a clone instead, put `prel.sh` on the `PATH` under the name `prel`:

```bash
git clone https://github.com/pdulvp/prel.git
sudo ln -s "$PWD/prel/prel.sh" /usr/local/bin/prel
```

Either way `prel` resolves the symlink before it looks for `scripts/`, so it
finds its own tree rather than the directory the link happens to sit in. A
clone is the better one to work from: the registrations are links back into it,
so an edit there is live everywhere it is registered, with nothing to reinstall.

## Configuring

The settings prel invented for itself live in `prel.config.json` at the root of
the repository being worked on. A file rather than git config, so it can be
committed: the version file, the build commands and the artifacts of a project
travel with the clone instead of being set once per machine by hand.

```json
{
  "versionFile": "VERSION",
  "tagPrefix": "v",
  "buildCommand": "make",
  "releaseBuildCommand": "packaging/build-deb.sh ${version}",
  "artifacts": ["build/prel_${version}_all.deb"],
  "plansDir": "docs/plans",
  "publicReleasesRepository": "acme/myapp-releases",
  "commands": [
    { "name": "deb", "launch": "packaging/build-deb.sh ${version}" }
  ]
}
```

Every key is optional, and so is the file: a repository with none takes the
defaults in the table below, which is most of them.

| key | what it is | default |
| --- | --- | --- |
| `versionFile` | where the version is, for `prel release` | `VERSION` |
| `tagPrefix` | what goes in front of the tag; `""` for none | `v` |
| `buildCommand` | the shell command `prel build` runs | none |
| `releaseBuildCommand` | the shell command that builds the release artifacts, run by `prel release` | none |
| `artifacts` | the globs to attach to the release | none |
| `plansDir` | where `prel issue-from-plans` looks for plans | `docs/plans` |
| `publicReleasesRepository` | a second GitHub repository, `owner/repo`, that [`prel public-release`](#prel-public-release) publishes a release on | none |

`prel config` prints the settings as prel reads them, marks the ones that are
defaults, and reports anything wrong with the file - including a key prel does
not know, which is a typo that would otherwise do nothing quietly.

The two build commands are two builds, not one with a long name. A project's
ordinary build is `buildCommand`, and [`prel build`](#prel-build) runs it; the
build that makes the files a release carries is `releaseBuildCommand`, and
`prel release` runs that one. Neither stands in for the other: a key not set
means there is no build to run, never the other build.

`releaseBuildCommand` was called `buildCommand` in 0.2.3, when the file was
introduced and there was one of them. A config written then names what prel now
reads as the ordinary build, so a release would build nothing - `prel release`
says as much on the `build:` line of its plan, before it writes anything, and
`prel release artifacts` says it under a pattern that matched no file.

Reading the file needs `jq`, and nothing else about prel does; the `.deb` has
it as `Recommends` for that reason. A repository with no `prel.config.json`
never reaches for it. Where the file is there and `jq` is not, prel says so and
stops rather than taking every setting at its default behind your back - a
release that quietly forgot its artifacts is the failure worth avoiding.

git's own settings are not in this file. `commit.coauthor`, `core.hooksPath`,
`commit.cleanup` and `include.path` are read by git itself, or by the
`configs/.gitconfig-*` includes that `prel switch-author` points at, and stay
in git config where git looks for them.

Earlier versions of prel read these five as `prel.*` git config keys. They are
read no more, and a repository still setting one is told about it by name -
silence there would look exactly like a setting that still works.

## Commands

### prel usage
Show detailed help for all available commands, and repeat the list of them at
the end: by then two hundred lines of help have scrolled past, and the end is
where a terminal leaves the reader. `prel` on its own, or `prel help`, prints
that list and nothing else.

### prel init
Register everything prel shares with a repository, in one go.

```bash
prel init usage             # Show help
prel init register          # Register the hooks, the skill and the memories
prel init register --copy   # Install the skill as a copy instead of a symlink
prel init unregister        # Remove the hooks and the memories from this repo
prel init status            # The state of all three, and what the next commit
                            # would file
```

prel shares three things with a repository, each with a command of its own: the
hooks that file the completed work plans (`prel hooks`), the skill that is the
format they read (`prel skills`), and the memories that make a session produce
something to file (`prel memory`).

All three are needed before `prel issue-from-plans` does anything, and missing
one leaves the feature inert without saying so - a repository with no memories
grows no plans, so there is never a sum-up to file, so no issue is ever filed.
`prel init` is the one command to run in a new repository, and the one to ask
afterwards.

`register` is safe to run again: each step reports what was already in place,
and leaves alone any local file of the same name that is not prel's. A step that
could not do its work says so and makes the whole command exit non-zero, because
a half-registered repository is the failure this command exists to surface.

`unregister` removes only what belongs to this repository - the hooks and the
memories. The skill lives in the user's skills directory and is shared by every
repository, so it is kept; remove it with `prel skills unregister`.

`status` adds the report of `prel issue-from-plans status` to the three, so one
command answers whether a commit here would file an issue, and why not.

### prel init-authored-hooks (or **hooks**)
Manage git hooks from the prel project.

```bash
prel init-authored-hooks usage          # Show help
prel init-authored-hooks register       # Set core.hooksPath to prel/.githooks
prel init-authored-hooks unregister     # Remove core.hooksPath setting
prel init-authored-hooks status         # Show whether they are registered

# Shortcut:
prel hooks register
prel hooks unregister
prel hooks status
```

`status` reports `core.hooksPath`, whether each hook is executable - git skips
one that is not, in silence - and what `commit.cleanup` will do to a `#12`
subject.

Registering also sets `commit.cleanup` to `scissors`, and unregistering puts it
back. That setting is what lets a commit subject start with the `#12` of the
issue `prel issue-from-plans` files: git cleans the message up *after* the hooks
have run, and its default mode drops every line starting with the comment
character - the subject included. Under `scissors` only what sits below the
scissors line is dropped, so the help text still goes and the subject stays.

New hooks need no re-register: `core.hooksPath` points at the prel checkout, so
a hook added there is live in every repository that registered it. Which is why
each hook is inert where it has nothing to do.

### prel switch-author (or **sa**)
Switch commit author and co-author mode.

```bash
prel switch-author usage    # Show help
prel switch-author          # Show current mode
prel switch-author default  # Use default (no co-author)
prel switch-author claude   # Use Claude mode
prel switch-author mistral  # Use Mistral Vibe mode

# Shortcut:
prel sa claude
prel sa mistral
prel sa default
```

### prel recommit-last (or **recommit**)
Rewrite the last N commits with the current author mode.

```bash
prel recommit-last usage       # Show help
prel recommit-last 3           # Rewrite the last 3 commits
prel recommit-last 3 -n        # Dry run: show what would change

# Shortcut:
prel recommit 3
```

Use it after `prel switch-author` when the last commits were made under the
wrong mode:

```bash
prel sa claude          # pick the mode the commits should have carried
prel recommit-last 3    # replay the last 3 commits under it
```

Each commit is replayed with the committer of the current mode and with its
message run back through the `prepare-commit-msg` hook, so a stale
`Co-Authored-By` trailer is replaced by the one the current mode asks for.
Trailers prel never wrote (real human co-authors) are left alone.

Author identity, author date and commit date are all preserved - only the
committer and the message change. The working tree and the index are never
touched, so this works on a dirty repository. Rewritten commits get new
hashes: the previous HEAD is printed and kept in the reflog, and a branch that
was already pushed needs a force push afterwards. Commit signatures do not
survive the rewrite.

### prel exclude-from-git (or **exclude**)
Rewrite history to drop files that should never have been committed.

```bash
prel exclude-from-git usage                   # Show help
prel exclude-from-git secrets.env             # Drop it from the whole history
prel exclude-from-git build/ '*.log'          # Pathspecs: directories and globs
prel exclude-from-git secrets.env -n          # Dry run: show what would change
prel exclude-from-git secrets.env --last 5    # Only rewrite the last 5 commits

# Shortcut:
prel exclude secrets.env
```

Use it when a file was committed that should not have been:

```bash
prel exclude-from-git secrets.env   # replay the history without it
echo secrets.env >> .gitignore      # and keep it out from now on
```

Each commit is replayed without the given paths. Author identity, committer
identity, author date and commit date are all kept as they are, and so is every
commit message: only the trees change. The `prepare-commit-msg` hook is
deliberately not run, so no `Co-Authored-By` trailer is added or removed here -
that is what `prel recommit-last` is for. Commits the paths never appeared in
keep their original hash.

A commit left with nothing in it is dropped, unless `--keep-empty` is given;
commits that were already empty are kept either way, and merge commits are never
dropped.

The files stay on disk: they are only removed from history and, unless
`--keep-index` is given, from the index, so the next commit does not add them
straight back. Paths are read relative to the directory the command is called
from, like any other git command.

Rewritten commits get new hashes: the previous HEAD is printed and kept in the
reflog, and a branch that was already pushed needs a force push afterwards. The
old objects stay in the repository until the reflog is expired and `git gc` runs
(the command prints how). Commit signatures do not survive the rewrite.

### prel reapply-releases
Re-point the tags and GitHub releases that a history rewrite left behind, then
force-push the branch.

```bash
prel reapply-releases usage    # Show help
prel reapply-releases -n       # Dry run: show what would move
prel reapply-releases          # Move the diverged tags and releases, force-push
```

After `prel exclude-from-git` rewrote the local branch, the tags on the remote
- and the releases attached to them - still point at the old commits. A tag has
diverged when the commit it points at is no longer an ancestor of the local
HEAD; it is then re-pointed at the local commit with the same message (a
rewrite keeps messages and dates), locally and on the remote. Its GitHub
release is recreated on the new tag with the same title, notes, flags and
assets - downloaded from the old release first, uploaded again after. Tags that
have not diverged are left alone. Finally the local branch is force-pushed onto
the same-named branch of the remote, with a lease on the tip read beforehand.

### prel issue-from-plans (or **issues**)
File the completed work plans of a repository as a GitHub issue, at commit time.

```bash
prel issue-from-plans usage      # Show help
prel issue-from-plans status     # What the next commit would file
prel issue-from-plans dry-run    # The issue and the message in full

# Shortcut:
prel issues status
```

In a repository that keeps work plans under `docs/plans/`, the prel hooks file
every plan marked `status: complete` and not yet carrying an `issue:` field as
**one** GitHub issue, and put its number in front of the commit subject:

```
#12 Paquetage Windows et équilibrage des rivaux

- zip Windows avec les DLL de Qt, les greffons et le runtime mingw
- huit compétences par rival, XP rééquilibrée
```

One issue covers the whole batch - its body is the sum-up followed by one
section per plan - because a plan and a commit rarely line up one to one. The
plans themselves stay out of git: the issue is what remains of them.

`docs/plans/sumup.md` is the trigger and supplies the wording. Its `# title`
line becomes the issue title and the commit subject, and what follows becomes
the commit body and the issue's lead. Without that file nothing is filed and the
commit is an ordinary one, which is also what keeps the hooks inert in every
repository that keeps no plans. The `plan-summary` skill is the format it
follows, written by the Claude Code session that finishes the work - installed
along with the rest by `prel init register`.

Once a commit carries the issue, `post-commit` stamps `issue: <n>` into each
plan it filed and deletes `sumup.md`.

A subject that already starts with an issue number is left alone, so
`prel recommit-last` - which replays messages back through the hook - and
`git commit --amend` do not file the same work twice. An issue filed for a
commit that never happened is remembered in `.git/prel-pending-issue` and
reused, so quitting the editor leaves no orphan.

Nothing here can stop a commit. A missing `gh`, an unauthenticated `gh`, no
GitHub remote, a `commit.cleanup` that would strip the number, a failing API
call: each is reported on stderr, the commit is made without a link, and
`sumup.md` is left in place for the next attempt. `PREL_SKIP_ISSUE=1 git commit`
skips the whole thing, and so does `git commit --no-verify`.

Plans are read from `docs/plans`, or from the `plansDir` of the repository's
[`prel.config.json`](#configuring).

### prel attach-issue (or **attach**)
File a commit already made as a GitHub issue, and put its number in front of
the subject.

```bash
prel attach-issue usage        # Show help
prel attach-issue             # File HEAD's message as an issue
prel attach-issue 515ed05     # Any commit of the branch, last or not
prel attach-issue --all       # Every unattached commit ahead of upstream
prel attach-issue 515ed05 -n  # Dry run: the issue it would file

# Shortcut:
prel attach --all
```

This is the counterpart of [`prel issue-from-plans`](#prel-issue-from-plans-or-issues),
which files an issue *at* commit time out of the work plans. Use this one for a
commit that is already in the history with a good message and no issue behind
it: the message *is* the issue.

The subject becomes the title, the rest of the message becomes the body, and
the identity trailers - `Co-Authored-By:`, `Committer:`, `Signed-off-by:` and
the like - are dropped from it, since the commit records all that already. The
commit then gets the number in front of its subject:

```
#12 A release target, and the build stamp moved behind a `~`
```

The commit keeps its message otherwise, trailers included.

**A commit that is not the last one is handled too.** The commits from it to
`HEAD` are replayed onto its rewrite, the way
[`prel recommit-last`](#prel-recommit-last-or-recommit) and
[`prel exclude-from-git`](#prel-exclude-from-git-or-exclude) already replay
them. Author identity, committer identity, author date and commit date are all
kept: only the message changes. Commits before the target keep their hash; the
target and everything after it get new ones, the previous HEAD is printed and
kept in the reflog, and a branch that was already pushed needs a force push -
which is said up front when the target is already on the upstream. Commit
signatures do not survive the rewrite. The working tree and the index are never
touched, so a dirty repository is fine.

Left alone, and said so: a subject already carrying an issue number - so a
second run is a no-op - a merge commit, and a commit that is not an ancestor of
`HEAD`.

`gh` and a GitHub remote are required here: unlike in the commit hooks, where
nothing may stop a commit, the issue is the whole point. An issue filed for a
rewrite that then failed is remembered in `.git/prel-attached-issue` and reused
by the next run, so a failure leaves no orphan behind.

### prel config
Show the settings this repository gives prel, and where they come from.

```console
$ prel config
file:                 prel.config.json
versionFile:          VERSION (default)
tagPrefix:            v (default)
buildCommand:         none (default)
releaseBuildCommand:  packaging/build-deb.sh ${version}
artifacts:            build/prel_${version}_all.deb
plansDir:             docs/plans (default)
publicReleasesRepository: none (default)
commands:             1 named command(s)
                      deb -> packaging/build-deb.sh ${version}

prel config: nothing to report
```

The settings and the file they live in are described under
[Configuring](#configuring). This command is what reads it: every key with its
value, `(default)` against the ones the file does not set, and `"" (empty, set
on purpose)` against a `tagPrefix` deliberately emptied to get a bare tag.

What it reports, on stderr, is anything wrong with the file: a key prel does
not read, named alongside the eight it does; a value of the wrong shape; a file
that is not a JSON object, or one that `jq` is not installed to read. It exits
`0` where there is nothing to say, `1` where there are warnings and `2` where
the file cannot be used as it stands - `prel release` runs the same check
before it writes anything, and refuses on a `2`.

A `prel.*` git config key left over from the versions that read them is a
warning here, naming the key and the JSON it should become.

### prel build
Run the project's build, without releasing anything.

```bash
prel build usage                  # Show help
prel build                        # Build at the version the version file reads
prel build 1.0.1                  # Build at a version not yet in the file
prel build -n                     # Show what would run, run nothing
prel build --release              # Run the release build instead
```

`buildCommand` is the project's build, and `prel build` runs it - nothing
committed, tagged, pushed or published:

```console
$ prel build
buildCommand:         make
version:              1.0.0 (from VERSION)
tag:                  v1.0.0

cc -O2 -o build/app src/main.c

prel build: 1.0.0 built
```

`releaseBuildCommand` is the other build a project may have: the one that makes
the files a release carries, which `prel release` runs between the tag and the
push. `prel build --release` runs that one, and stops there, so the build a
release will depend on can be tried as often as it takes rather than first
running on the release itself:

```console
$ prel build --release
releaseBuildCommand:  packaging/build-deb.sh ${version}
version:              0.2.3 (from VERSION)
tag:                  v0.2.3

Built build/prel_0.2.3_all.deb (0.2.3, given)

artifacts:
  build/prel_0.2.3_all.deb

prel build --release: 0.2.3 built
```

Neither key stands in for the other: with no `buildCommand`, `prel build` says
so and exits 0 rather than reaching for the release build, and the same the
other way round.

The command runs from the repository root, with `$version` set to the version
being built and `$tag` to the tag it would get - the same two a release gives
it, which is how `"packaging/build-deb.sh ${version}"` knows what it is
building. The version is the one in the version file as it stands, or the one
given: `prel build --release 1.0.1` builds what `prel release 1.0.1` would
build.

The exit status is the build's own, so a script can gate on it. Where
`artifacts` is set, what its patterns match is printed after a build that
worked - as a report, not a verdict: `prel release artifacts` is the one that
exits non-zero over a pattern that matched nothing.

### prel run
Run one of the named commands of `prel.config.json`, with the arguments after
the name appended to it.

```bash
prel run usage                  # Show help
prel run                        # List the named commands
prel run deb                    # Run the command called "deb"
prel run test unit              # Run "test" with "unit" appended
prel run -n deb                 # Show what would run, run nothing
```

`commands` is a list of objects, each a `name` and the `launch` shell command
run under that name:

```json
"commands": [
  { "name": "deb", "launch": "packaging/build-deb.sh ${version}" },
  { "name": "test", "launch": "make test" }
]
```

```console
$ prel run deb
command:              deb
launch:               packaging/build-deb.sh ${version}
version:              0.2.11
tag:                  v0.2.11

Built build/prel_0.2.11_all.deb (0.2.11)

prel run: 'deb' done
```

The launch runs from the repository root with `$version` and `$tag` set the
same way [`prel build`](#prel-build) sets them, so `${version}` in a launch is
the version the version file reads. Every argument after the name is appended
to the launch, quoted one by one, so `prel run test "a b"` passes `a b` as one
argument. The exit status is the command's own. A name the file does not
define is an error that lists the names it does; with no name at all,
`prel run` lists the commands and runs nothing.

### prel release
Move the VERSION file on, tag it, push it and publish the release.

```bash
prel release usage                # Show help
prel release artifacts            # Say what the artifacts setting matches
prel release artifacts 1.0.1      # The same, for a version not yet in the file
prel release artifacts micro      # The same, for the version a level would give
prel release major                # Release 1.0.0 from a file reading 0.2.7
prel release minor                # Release 0.3.0 from a file reading 0.2.7
prel release micro                # Release 0.2.8 from a file reading 0.2.7
prel release current              # Release the version the file already reads
prel release 1.0.1                # Bump, commit, tag, push, publish
prel release 1.0.1 -n             # Show every step, change nothing
prel release 1.0.1 -y             # Do not ask about uncommitted changes
prel release 1.0.1 -m "..."       # Message for the commit and the tag
prel release 1.0.1 --draft        # Publish the GitHub release as a draft
prel release 1.0.1 --no-build     # Upload the artifacts without building them
prel release 1.0.1 --no-assets    # Build nothing, upload nothing
prel release 1.0.1 --no-release   # Commit, tag and push, publish nothing
prel release 1.0.1 --no-milestone # Create no milestone, move no issue
```

For a project that keeps its version in a `VERSION` file at its root - three
numbers in a file, which the build reads and nothing has to parse out of source
code - a release is that file moved on and the commit it was moved in made
public. Nine steps, stopping at the first that fails:

1. write `1.0.1` into the `VERSION` file
2. commit that file alone
3. tag the commit, annotated, as `v1.0.1`
4. build the artifacts, where `releaseBuildCommand` says how
5. push the branch and the tag
6. create the GitHub release, its notes the commits since the last tag
7. upload the artifacts in `artifacts`, then take the release out of draft
   now that it has them
8. put the issues these commits fixed on a milestone named after the tag, and
   close them and it
9. emit the pbus event `prel.release.published`, its payload a JSON object
   naming the version (`{"version": "1.0.1"}`), so whatever waits on a release
   starts without the release waiting for it

#### The version, or the word for it

Which of the three a release is, is known long before what it is called, and
the number is a sum done in the head over a file that is right there. So the
three names go where the version goes - `major`, `minor` and `micro` move that
digit of the version file and release what that gives:

```console
$ cat VERSION
0.2.7
$ prel release micro -n --no-release
release:      0.2.7 -> 0.2.8 (micro)
version file: VERSION
commit:       Release 0.2.8
tag:          v0.2.8 (annotated)
push:         origin main, origin v0.2.8
```

`patch` is `micro` under its other name. `current` is the fourth word and no
move at all: the version the file already reads, released as it stands, for one
moved on by hand or by a script.

A pre-release suffix comes off whichever digit moves, so a `micro` off
`1.2.3-rc1` is `1.2.3` - the release the candidate was a candidate for - while
a `minor` off it is `1.3.0`, as it is off `1.2.3`.

Nothing else about a release changes: the same commit, tag, build, push,
publish, milestone and event, at a version it worked out rather than one it was
given. `prel release micro -n` shows the number before a release is made at it,
and either way the first line says which version came out of the word.
`prel release artifacts micro` answers the same word with the files that
version would upload.

#### Release artifacts

Steps 4 and 7 are there for a project whose build produces files that belong on
the release - a `.deb`, a Windows `.zip` - and are skipped entirely by one that
has not asked for them in its [`prel.config.json`](#configuring):

```json
{
  "releaseBuildCommand": "cmake --build build --target release",
  "artifacts": ["build/*.deb", "build-win/*.zip"]
}
```

`artifacts` is a list of globs read from the repository root. One entry is one
pattern, so a path with a space in it is as expressible as any other; a single
string of patterns separated by whitespace is accepted too, which is what the
git config value it replaces had to be.

A pattern can also name the release it is for, instead of globbing over every
release ever built - `build/myapp-*.deb` happily uploads the `.deb` from last
time alongside this one:

```json
{ "artifacts": ["build/myapp-${version}.deb", "dist/myapp-${tag}.zip"] }
```

`${version}` is the version being released, `1.0.1`, and `${tag}` the tag it
gets, `v1.0.1`; the bare `$version` and `$tag` work too. No shell is involved:
they are filled in by plain string replacement, so a pattern becomes a filename
and nothing in it is allowed to run. `releaseBuildCommand` *is* a shell
command, and sees the same two as `$version` and `$tag`.

A misspelt name is left as it stands, matches no file and so stops the release
before the push, naming the two it knows. Attempting a release is a poor way to
discover a typo, though, so there is a command that only looks:

```console
$ prel release artifacts
artifacts: build/myapp-${version}.deb build-win/myapp-${tag}.zip
version:   1.0.1 (from VERSION)
tag:       v1.0.1

filled in:
  build/myapp-${version}.deb -> build/myapp-1.0.1.deb
  build-win/myapp-${tag}.zip -> build-win/myapp-v1.0.1.zip
would upload:
  build/myapp-1.0.1.deb
matched nothing:
  build-win/myapp-v1.0.1.zip
  a release would build them first: cmake --build build --target release

1 pattern(s) matched nothing; a release would stop before the push
```

`prel release artifacts` needs none of what a release needs - no network, no
`gh`, no free tag, nothing written and nothing built. The version is the one in
the `VERSION` file as it stands, or the one given as `prel release artifacts
1.0.1` for a release not yet made. It exits non-zero where a pattern matched no
file, so a build script can gate on it.

Two things about the order are deliberate. The build runs **before the push**,
while the commit and the tag are still only local: a build that fails there
undoes both and leaves nothing published, rather than a public tag whose
release holds no files and a version that cannot be released again. And the
release is created as a **draft** whenever there are artifacts, taken out of
draft only once they are all up, so it is never visible without them -
`--draft` simply leaves it there.

A pattern that matches no file stops the release, before the push, for the same
reason: that is how a release goes out missing the one artifact nobody thought
to check for. The upload is `--clobber`, so a release left half-uploaded by a
dropped connection can be finished by running the upload again.

`--no-build` uploads the artifacts as they already are on disk, for a build
done by hand or by CI. `--no-assets` skips both steps, and `--no-release`
implies it - with nowhere to upload to, the build would be work for nothing.

The build itself is worth trying before a release leans on it, which is what
[`prel build --release`](#prel-build) is for: the same command, from the same
directory, with the same `$version` and `$tag`, and no commit or tag around it.
Plain `prel build` runs `buildCommand`, the ordinary build of the project,
which a release never runs.

#### Release milestones

Step 8 collects the issues a release fixed onto a GitHub milestone of its own,
named after the tag:

```console
$ prel release 0.2.2
...
Created milestone v0.2.2 (#1)
Put #4, #5, #6 on v0.2.2 and closed them
Closed milestone v0.2.2
```

Which issues those are is read out of the commits the release carries - the
same range the notes are written from - and `prel issue-from-plans` is what put
them there: it files the finished work as an issue and puts that number in
front of the commit subject, so `#6 MIT licence, shipped as the package's
copyright file` says in the history itself which issue the commit answered.
Every `#<n>` in those subjects goes on the milestone.

Subjects only. A commit filed by prel carries a `filed as issue #<n>` line in
its body as well, and reading bodies would put the same issue on every
milestone made after it.

A project whose commits name no issue gets no milestone - an empty one per
release is worse than none at all - so there is nothing to switch on here, and
`--no-milestone` switches it off. `--no-release` implies it: with no release
there is nothing for a milestone to be named after.

The milestone is created if it is not there and reused if it is, so a release
retried after a failed upload does not leave a second one behind. An issue
already on **another** milestone stays there - an earlier release is where it
was fixed - and a `#<n>` that answers to no issue, a pull request or a stray
number, is reported rather than acted on.

This is the last step, after the release has been taken out of draft, and the
one step that never fails a release: by then the tag is pushed and the
artifacts are up, and a milestone left half-made does not make any of that
wrong. What it could not do it says, with the `gh` command that finishes it.

`--draft` fills the milestone but closes nothing, neither the issues nor the
milestone itself: a draft has not shipped, so the work on it is not released
yet.

Nothing is touched before every precondition is checked: a `VERSION` file to
move, a three-number version (a `-rc1` suffix allowed), a branch rather than a
detached HEAD, a tag free both here and on the remote, and a usable `gh` unless
`--no-release` says not to publish. A release half made is worse than one not
started - which is also why a failure after the commit says what is local and
what is pushed.

Uncommitted changes are not carried into a release. Where the tree has any, the
command lists them and asks, since committing the version alone leaves them
exactly where they were:

```
This tree has changes that will NOT be part of the release:
   M app.txt
  ?? scratch.txt

Only VERSION would be committed; these stay exactly as they are.
Release 1.0.1 anyway? [y/N]
```

`-y` answers yes in advance, and no terminal to ask on is an answer of no - a
command that pushes and publishes does not take a redirected pipe for consent.

The tag is `v<x.y.z>`, or the version alone where `tagPrefix` is set to an
empty string. The file is `VERSION`, or the path in `versionFile`. Both are
read from [`prel.config.json`](#configuring), and a release checks that file
over before it writes anything: a key prel does not read or a value of the
wrong shape stops it where nothing has happened yet. The
release commit is made with `PREL_SKIP_ISSUE` set, so it never spends the issue
that `prel issue-from-plans` is holding for the next real commit.

#### Announcing the release on pbus

Step 9 is for whatever has to happen *because* a release went out: a site
rebuilt, a package pushed somewhere else, a notification on a desktop. None of
it is the release's work to wait for, and none of it belongs in prel.

[pbus](https://github.com/pdulvp/pbus-events) is the dispatcher that owns that part -
a command registers against an event name, and the daemon starts it when the
event is emitted. `prel release` emits one event, once the release is really
out:

```
pbus: Event "prel.release.published" accepted (id 7287118827db1d69), 2 listener(s) triggered.
```

The payload is a JSON object and nothing else - `{"version": "1.0.1"}`, not
`1.0.1` and not `v1.0.1`. The event is declared once per machine, by `sudo
prel init-pbus register`, which is also where the listeners are documented.

Each artifact the release uploads raises its own event as well,
`prel.release.artifact.<ext>.published` - `prel.release.artifact.deb.published`
for a `.deb` - with a payload naming the version and the GitHub repository the
release was published on: `{"version": "1.0.1", "repository": "owner/repo"}`.
Those events are declared one at a time, like any pbus event:

```bash
sudo pbus register-event prel.release.artifact.deb.published \
     -d "A .deb of a prel release has been published" \
     --payload-pattern '^\{"version": "[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?", "tag": "(-[0-9A-Za-z.-]+)?[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?", "repository": "[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"\}$' \
     --save
```

Nothing about this can cost a release. The emit is the last step for the same
reason the milestone is: by then the tag is pushed and the release is
published, so there is nothing left for a failure to spoil. pbus not installed
or the event not declared is silence - most machines, and the reason the `.deb`
has pbus as `Recommends` rather than `Depends`. A daemon that is not running, a
key that cannot be found or a payload the event refuses is a warning naming the
`pbus emit` to run again by hand:

```
Warning: 1.0.1 is released; it is the pbus event that did not go out
         pbus: the bus does not exist (/run/pbus/bus): is pbusd running?
         emit it again with:
           pbus emit prel.release.published --payload '{"version": "1.0.1"}'
```

Nothing is emitted for a `--draft` or under `--no-release`: neither has
published anything to announce. `prel release -n` says which of these applies
before anything is done, on the `pbus:` line of its report.

### prel public-release
Publish a release on the public releases repository, without touching this one.

```bash
prel public-release usage         # Show help
prel public-release 1.0.1         # Publish 1.0.1 on publicReleasesRepository
prel public-release micro         # The version a level gives, from the VERSION file
prel public-release current       # The version the VERSION file already reads
prel public-release 1.0.1 -n      # Show every step, change nothing
prel public-release 1.0.1 -m "…"  # Message for the commit and the tag
prel public-release 1.0.1 --draft # Publish the GitHub release as a draft
```

`publicReleasesRepository` in [`prel.config.json`](#configuring) names a second
GitHub repository, as `owner/repo` - a releases-only repository holding nothing
but the version, the tag and the release with its artifacts:

```json
{ "publicReleasesRepository": "acme/myapp-releases" }
```

The command clones that repository into a temporary directory, writes the same
`versionFile` there with the version being published, commits that file alone,
tags the commit as `v1.0.1` (the `tagPrefix` of this repository), pushes the
branch and the tag, then creates the GitHub release there with the notes this
repository's commits make, and uploads the `artifacts` **copied from this
repository's tree** - the files `prel release` built, not a build run again. No
build runs here, and a pattern matching no file stops the command before
anything is cloned.

This repository is only read, never written: its `VERSION` file is not touched,
and the commit and the tag are made in the clone. The version can be given or
worked out - `major`, `minor`, `micro`, `current` read the version file here
exactly as `prel release` does - so `prel release 1.0.1` followed by
`prel public-release 1.0.1` publishes the same release on both repositories.

The release on the public repository is created as a **draft** whenever there
are artifacts, taken out of draft once they are all up; `--draft` leaves it a
draft. A tag already on the public repository is reported and nothing is pushed,
so publishing the same version twice is a no-op. There is no milestone and no
pbus event there: the issues live in this repository, and the release is
announced once, by `prel release`.

### prel init-skills (or **skills**)
Make the prel agent skills available to Claude Code.

```bash
prel init-skills usage            # Show help
prel init-skills register         # Link prel/skills into ~/.claude/skills
prel init-skills register --copy  # Copy them instead of linking
prel init-skills unregister       # Remove them
prel init-skills status           # Show which ones are installed

# Shortcut:
prel skills register
```

Links the skills shipped in `prel/skills` into `$CLAUDE_CONFIG_DIR/skills`
(`~/.claude/skills` by default), so every project loads them, the way
`prel hooks register` shares the hooks. A symlink means an edit in the prel
checkout takes effect at once.

Shipped today:

- **plan-summary** - the format of `docs/plans/sumup.md`, which
  `prel issue-from-plans` turns into a GitHub issue and a commit subject.

### prel init-memory (or **memory**)
Share prel's agent memories with a repository - Claude Code and Mistral Vibe.

```bash
prel init-memory usage         # Show help
prel init-memory register      # Link prel's memories into this project
prel init-memory unregister    # Remove them from this project
prel init-memory status        # Show which ones are linked

# Shortcut:
prel memory register
```

Claude Code keeps its memories per project, under
`$CLAUDE_CONFIG_DIR/projects/<the repo path with dashes>/memory`. A convention
shared by several repositories would have to be written there once per
repository, and would then drift.

`register` links the memories shipped in `prel/memory` into the current
repository's memory directory and splices their index lines into its
`MEMORY.md`, between the markers prel owns. The memories themselves stay in the
prel checkout: that is where they are edited, and every registered repository
sees the edit at once.

Memories belonging to one repository alone - its build, its stack - stay where
they are. prel only ever rewrites its own block of `MEMORY.md`, and refuses to
touch a local file of the same name that says something different.

Mistral Vibe keeps no per-project memory directory of its own, so `register`
gives it one at the same location Claude Code uses, under the Vibe config dir:
`$VIBE_CONFIG_DIR/projects/<the same dash-slug>/memory`
(`~/.vibe/projects/<slug>/memory` by default), and splices a loader block into
the user-level `~/.vibe/AGENTS.md` - `AGENTS.md` being what Vibe loads at the
start of every session, in every project. The block tells the session to read
`~/.vibe/projects/<slug>/memory/MEMORY.md` and every memory file it links, so the
memories are standing instructions from the first turn. The linked files
resolve into the prel tree, which sits outside a consumer project's workspace:
where the `.deb` is installed that is `/usr/share/prel`, so add
`/usr/share/prel/memory` (or the clone's `memory/`) to
`~/.vibe/trusted_folders.toml` for Vibe to read them from another project.

Shipped today:

- **write-plan-before-coding** - write the steps to `docs/plans/plan.md` first,
  mark it complete, sum it up, archive it.
- **resume-from-plan-file** - on "continue where you left off", read the newest
  plan in `docs/plans/` before anything else.

Both are the convention `prel issue-from-plans` and the `plan-summary` skill are
built around, so a repository using those wants them.

### prel init-pbus
Declare the pbus event a published release emits.

```bash
prel init-pbus usage            # Show help
sudo prel init-pbus register    # Declare prel.release.published
sudo prel init-pbus unregister  # Remove it
prel init-pbus status           # What a release here would emit, and to whom
```

[pbus](https://github.com/pdulvp/pbus-events) is an event dispatcher: a command
registers against an event name and the daemon launches it when that event is
emitted. `prel release` emits `prel.release.published` as its
[last step](#announcing-the-release-on-pbus), with a JSON payload naming the
version, and one `prel.release.artifact.<ext>.published` event per uploaded
artifact, its payload naming the version, the git tag and the GitHub repository.
An event has to be declared before anything may emit it, and declaring one
writes `/etc/pbus` - hence the `sudo`, and hence a command of prel's own rather
than a line in the README to copy.

`register` declares the event with a description and a payload pattern of the
JSON shape the payload has, so a listener may read the version out of
`"$PBUS_PAYLOAD"` with `jq -r .version`: the daemon refuses anything else
before a single listener starts. There is no
shortcut named `pbus` for this command, by the way - `prel.sh` sources every
script into one shell, and a function of that name would shadow the pbus binary
the release emits through.

It is machine-wide and once and for all, unlike `prel init`, which registers
what belongs to one repository. An event already declared is left exactly as it
is: declaring it again would draw a new key and silently break whoever holds the
old one, so `register` says what is there and points at
`sudo pbus rotate-key prel.release.published --save` for the case where a new
key is what was wanted.

The key is the one thing worth knowing about. An emission presents a key and the
daemon refuses one that does not match, which is what stops any account on the
machine from firing a deployment. `register` keeps it in root's keyring and
hands a copy to the account that called `sudo`, because that account - not root
- is the one that runs `prel release`:

```
$ sudo prel init-pbus register
Declared pbus event: prel.release.published
  description:     A prel release has been published
  payload pattern: ^\{"version": "[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?"\}$
  key:             /etc/pbus/keys/prel.release.published (root)
  key:             /home/alice/.config/pbus/keys/prel.release.published (alice)
```

Subscribing to the event is pbus's business, not prel's - prel emits, and what
listens is a local decision:

```bash
sudo pbus register-listener prel.release.published --id notify \
     -u root 'pbus-notify -u alice "prel $(jq -r .version) published"'
```

`status` needs no privileges and answers what a release from here would do:
whether pbus is installed, whether the event is declared, whether this account
holds a key for it, what shape of payload the event accepts, and which
listeners it would trigger.

## Direct Script Usage

Scripts can also be run directly from the `scripts/` directory:

```bash
/mnt/Data/Works/prel/scripts/switch-author.sh claude
/mnt/Data/Works/prel/scripts/init-authored-hooks.sh register
/mnt/Data/Works/prel/scripts/recommit-last.sh 3
/mnt/Data/Works/prel/scripts/exclude-from-git.sh secrets.env
/mnt/Data/Works/prel/scripts/issue-from-plans.sh status
/mnt/Data/Works/prel/scripts/attach-issue.sh HEAD~2
/mnt/Data/Works/prel/scripts/init-skills.sh register
/mnt/Data/Works/prel/scripts/init-memory.sh register
/mnt/Data/Works/prel/scripts/init-pbus.sh status
/mnt/Data/Works/prel/scripts/init.sh status
/mnt/Data/Works/prel/scripts/build.sh
```

A script that uses another's functions loads it from the same directory first
when it is run directly, since only `prel.sh` sources them all: `init.sh`
drives the other commands, `build.sh` and `release.sh` share the config reader
and the build runner.

## Packaging

`packaging/build-deb.sh` builds the `.deb`:

```bash
packaging/build-deb.sh            # at the version in the VERSION file
packaging/build-deb.sh 0.2.0      # at that version instead
```

It writes `build/prel_<version>_all.deb`, staging the package tree beside it.
Both are gitignored. `dpkg-deb` is all it needs - no `debian/` directory, no
`dpkg-buildpackage`, no changelog, since an architecture-independent shell
package has nothing those would do for it. There is no apt repository: the
`.deb` goes on the release page and is installed by hand.

It is in `packaging/` rather than `scripts/` on purpose. `prel.sh` sources
every `scripts/*.sh` and turns it into a command, so this script there would
ship a `prel build-deb` to everyone who installs the package - a command about
prel's own clone, in the hands of people who do not have one. In a clone it is
`prel build --release` that runs it, through prel's own `releaseBuildCommand`;
run in another repository, the same command builds whatever that one's config
names.

The payload is named file by file in the script, a whitelist rather than a
blacklist: a top-level directory added to the repository later has to be named
there before it ships. The package also sets its own modes instead of
inheriting the clone's, which are group-writable and in places mode 770 -
installed root-owned under `/usr/share`, that would leave
`/usr/share/prel/prel.sh` unreadable to every user but root, and the package
would install cleanly and then refuse to run.

`prel release` builds and attaches it through the two settings in prel's own
`prel.config.json`, which is committed, so a fresh clone has them:

```json
{
  "releaseBuildCommand": "packaging/build-deb.sh ${version}",
  "artifacts": ["build/prel_${version}_all.deb"]
}
```

`${version}` is left as it stands in the file rather than written out as
today's version: `prel release` fills it in at release time, which is how the
build is told which version it is building and how the artifact is found once
it has. `prel release artifacts` says what they resolve to without building
anything.

That file is **not in the payload**. It is the configuration of
prel-the-repository, and an installed prel reads the `prel.config.json` of
whatever repository it is run in - one shipped under `/usr/share/prel` would be
a set of settings nobody asked for. The whitelist leaves it out by
construction, and the build fails if it ever turns up in the staged tree
anyway.

## Configuration Files

- `configs/.gitconfig-claude` - Claude mode attribution
- `configs/.gitconfig-mistral` - Mistral Vibe mode attribution
- `configs/.gitconfig-base` - Base configuration
- `.githooks/prepare-commit-msg` - Files the completed plans as an issue, then
  adds the Co-Authored-By trailer
- `.githooks/commit-msg` - Puts the issue number back in front of the subject
  should it have been edited away
- `.githooks/post-commit` - Stamps the filed plans and consumes their sum-up
- `skills/plan-summary/SKILL.md` - The format of `docs/plans/sumup.md`
- `memory/*.md` - agent memories shared across repositories: linked into each
  project's Claude memory directory and Vibe memory directory
  (`~/.vibe/projects/<slug>/memory`), with the `INDEX.md` lines spliced into
  each `MEMORY.md` and a loader block in `~/.vibe/AGENTS.md`

Read from the repository being worked on, not from prel:

- `prel.config.json` - the settings prel reads there: `versionFile`,
  `tagPrefix`, `buildCommand`, `releaseBuildCommand`, `artifacts` and
  `plansDir`, every one of them optional and the file with them. See [Configuring](#configuring), and
  `prel config` for what it resolves to
- `VERSION` - the three numbers `prel release` moves on, or the path in
  `versionFile`
- `docs/plans/` - the work plans `prel issue-from-plans` files, or the path in
  `plansDir`

## How It Works

The prel project maintains its own set of git configuration files and hooks. When you run `prel switch-author`, it sets the `include.path` in your repository's git config to point to the appropriate prel config file, which then includes the base config and sets committer/co-author information.

Git itself does not read `committer.name` / `committer.email`: those record what
the mode *should* commit as, and `prel recommit-last` is what applies them to
commits that were made under another identity.

Similarly, `prel init-authored-hooks register` sets `core.hooksPath` to use the hooks from the prel project, so all repositories can share the same hook implementations.

The hooks share one rule: they only ever add to a commit, never stop one. Each
is also inert where it has nothing to do - no `commit.coauthor`, no
`docs/plans/sumup.md` - because `core.hooksPath` makes every hook live in every
repository that registered prel, including those that want none of this.

`prel init-skills register` and `prel init-memory register` work the same way
for the agent skills and the shared memories: links in `~/.claude/skills` and in
each project's memory directories (`~/.claude/projects/<slug>/memory` and
`~/.vibe/projects/<slug>/memory`) rather than a copy per project, so the prel
checkout stays the single place they are edited.

Those three registrations are independent, and the issue filing needs all of
them, so `prel init` runs them together and `prel init status` reports them
together - a repository missing one looks exactly like a repository where the
hooks simply had nothing to do.

## License

MIT - see [LICENSE](LICENSE). The package installs it as
`/usr/share/doc/prel/copyright`, where Debian policy puts it.
